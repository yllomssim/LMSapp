﻿global using LMSGUIApp.Models;
global using LMSGUIApp.Pages;
global using LMSGUIApp.ViewModels;
global using SQLite; //for SQLiteConnection
global using System.Collections.ObjectModel; //for ObservableCollection
global using static Microsoft.Maui.Storage.FileSystem;// <-- add in manually -- for copying asset files
