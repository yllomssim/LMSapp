﻿namespace LMSGUIApp;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
    }
}